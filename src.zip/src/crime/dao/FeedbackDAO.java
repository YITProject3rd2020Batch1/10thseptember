package crime.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import crime.model.*;

public class FeedbackDAO {
	private static Connection con; 
	private static PreparedStatement stmt;
	public static void getConnection()
	  {
		
		  String JdbcURL = "jdbc:mysql://localhost:3306/crimedb?" + "autoReconnect=true&useSSL=false";
	      String Username = "root";
	      String password = "";
	       con = null;      
	      try 
	      {
	    	 Class.forName("com.mysql.jdbc.Driver");   // Driver should be registered
	         con = DriverManager.getConnection(JdbcURL, Username, password);
	         
	      } 
	      catch (Exception e) 
	      {
	         e.printStackTrace();
	      }
		   
		 
	  }
	  public static void closeConnection()
	  {
		  try{
			  if(con.isClosed()==false)
		          con.close();   // closing the connection
		  }
		  catch(Exception e)
		  { e.printStackTrace();	 }
	  }
	  
	  
	  public static boolean feedback(Complaintmodel feed)
	  {
		  int nor=0;
		  try{
			  getConnection();
			  stmt=con.prepareStatement("update complaint set usr_rmk=? where com_id=?");
			  stmt.setString(1, feed.getUsr_rmk());
			  stmt.setInt(2, feed.getCom_id());
			 
			 nor= stmt.executeUpdate();
			 closeConnection();
			   if (nor>0)
			   {
				   return true;
			   }
			   else
				   return false;
			    }
			  catch(SQLException e)
			  {
			  e.printStackTrace();
			  return false;
			  }
			  catch(Exception e)
			  {
			  e.printStackTrace();
			  return false;
			  }  	  	  
			  
		  }
	  public static boolean feedback1(Complaintmodel feed1)
	  {
		  int nor=0;
		  try{
			  getConnection();
			  stmt=con.prepareStatement("update complaint set adm_rmk=?, asgd_po=? where com_id=?");
			  stmt.setString(1, feed1.getAdm_rmk());
			stmt.setString(2, feed1.getAsgd_po());
			  stmt.setInt(3, feed1.getCom_id());
			 nor= stmt.executeUpdate();
			 closeConnection();
			   if (nor>0)
			   {
				   return true;
			   }
			   else
				   return false;
			    }
			  catch(SQLException e)
			  {
			  e.printStackTrace();
			  return false;
			  }
			  catch(Exception e)
			  {
			  e.printStackTrace();
			  return false;
			  }  	  	  
			  
		  }

}
