package crime.dao;




import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import crime.model.*;

public class ViewDAO
{
  private static Connection con; 
  private static PreparedStatement stmt;
  
public static void getConnection()
  {	 	
	  String JdbcURL = "jdbc:mysql://localhost:3306/crimeDB?" + "autoReconnect=true&useSSL=false";
      String Username = "root";
      String password = "";
       con = null;      
      try 
      {
    	 Class.forName("com.mysql.jdbc.Driver");   // Driver should be registered
    	 // con=DriverManager.getConnection( "jdbc:mysql://localhost:3306/test1","root","");  
         con = DriverManager.getConnection(JdbcURL, Username, password);
         
      } 
      catch (Exception e) 
      {
         e.printStackTrace();
      }
	   
	 
  }
  public static void closeConnection()
  {
	  try{
		  if(con.isClosed()==false)
	          con.close();   // closing the connection
	  }
	  catch(Exception e)
	  { e.printStackTrace();	 }
  }  
  
  
  //fetch the details
  
  public static ArrayList<String> getAllType()
  {
	  ArrayList<String> alltype=new ArrayList<String>();	  
	  try
	  {
	  getConnection();
      stmt=con.prepareStatement("select distinct com_type from complaint");       
	  ResultSet rs=stmt.executeQuery();  
	  while(rs.next())
		  {  
		    	alltype.add(rs.getString(1)); 		
		  }  
	     closeConnection();	 
	     return alltype;
	  }
	  catch(SQLException e)
	  {	  e.printStackTrace();	 return null; }
	  catch(Exception e)
	  {	  e.printStackTrace();	 return null; }  	  
  }
  
 
  
  public static ArrayList<Complaintmodel> getComplaintByType(String com_type)
  {
	  ArrayList <Complaintmodel> complaints=new ArrayList<Complaintmodel>();
	  Complaintmodel temp; 
	  	  
	  try
	  {
	  getConnection();
      stmt=con.prepareStatement("select com_id, com_type, date, victim_det, location, det_com from complaint where com_type=?"); 
      stmt.setString(1, com_type);
	  ResultSet rs=stmt.executeQuery();  
	  while(rs.next())
		  {  		   
		  temp = new Complaintmodel(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4),rs.getString(5), rs.getString(6));
		  complaints.add(temp); 		  
		  
		  }  
	     closeConnection();	 
	     return complaints;
	  }
	  catch(SQLException e)
	  {	  e.printStackTrace();	 return null; }
	  catch(Exception e)
	  {	  e.printStackTrace();	 return null; }  	  
  }
 
  
 //Edit complaint part 
  
  public static Complaintmodel getComplaintsByCom_id(int com_id)
  {
	  Complaintmodel temp=null;	  	  
	  try
	  {
	  getConnection();
      stmt=con.prepareStatement("select com_id, com_type, date, victim_det, location, det_com from complaint  where com_id=?"); 
      stmt.setInt(1, com_id);
	  ResultSet rs=stmt.executeQuery(); 
	  boolean flag=false;
	  if(rs.next())
		  {  		

		  temp=new Complaintmodel (rs.getInt(1), rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6));	
          flag=true;
		  }  
	     closeConnection();	 
	     if(flag==true)
	       return temp;
	     else
	    	 return null;
	  }
	  catch(SQLException e)
	  {	  e.printStackTrace();	 return null; }
	  catch(Exception e)
	  {	  e.printStackTrace();	 return null; }  	  
  }
  public static boolean updateComplaintByCom_id(Complaintmodel temp)
  {
	 	  	  
	  try
	  {
	  getConnection();
      stmt=con.prepareStatement("update complaint set com_type=?,det_com=?, location=?, victim_det=?, date=? where com_id=?"); 
      stmt.setString(1, temp.getCom_type());
      stmt.setString(2, temp.getDet_com());
      stmt.setString(3, temp.getLocation());
      stmt.setString(4, temp.getVictim_det());
      stmt.setString(5, temp.getDate());
      stmt.setInt(6, temp.getCom_id());
	  System.out.println(stmt.toString());
	  boolean flag=false;
	  int nor=stmt.executeUpdate();
	    closeConnection();	 
	     if(nor>0)
	       return true;
	     else
	    	 return false;
	  }
	  catch(SQLException e)
	  {	  e.printStackTrace();	 return false; }
	  catch(Exception e)
	  {	  e.printStackTrace();	 return false; }  	  
  }
 
  
 //Delete complaint part 
  
  public static boolean deleteComplaintBycom_id(int com_id)
  {
	  try
	  {
	  getConnection();
      stmt=con.prepareStatement("delete from complaint where com_id=?"); 
      
      stmt.setInt(1, com_id);
    
	  System.out.println(stmt.toString());
	  boolean flag=false;
	  int nor=stmt.executeUpdate();
	    closeConnection();	 
	     if(nor>0)
	       return true;
	     else
	    	 return false;
	  }
	  catch(SQLException e)
	  {	  e.printStackTrace();	 return false; }
	  catch(Exception e)
	  {	  e.printStackTrace();	 return false; }  
	  
  }
}
