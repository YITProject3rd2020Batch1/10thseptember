package crime.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import crime.dao.*;
import crime.model.*;

@WebServlet("/Delete")
public class Delete extends HttpServlet {
	private static final long serialVersionUID = 1L;
       


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher rd=null;
		int com_id;
		
	Complaintmodel temp=new Complaintmodel ();
		if(request.getParameter("oper")!=null)
		{
			if(request.getParameter("oper").equals("delete"))
			{
				
				com_id=Integer.parseInt(request.getParameter("com_id"));					
			    temp.setCom_id(com_id);
			    temp=ViewDAO.getComplaintsByCom_id(com_id);
			    if(temp!=null)
			    {
			    	
			    	request.setAttribute("complaint", temp);
			    	rd=request.getRequestDispatcher("del_com.jsp");
			    	rd.forward(request, response);	
			    	
			    }		    
			}
		}
		
		if(request.getParameter("confirmdelete")!=null)
		{
			com_id=Integer.parseInt(request.getParameter("com_id"));	
			if(ViewDAO.deleteComplaintBycom_id(com_id))
			{
				request.setAttribute("successmsg", "Updated succssfully");
				rd=request.getRequestDispatcher("view.jsp");
				rd.forward(request, response);	
			}
			else
			{
				request.setAttribute("errormsg", "Not updated");
				rd=request.getRequestDispatcher("del_com.jsp");
				rd.forward(request, response);	
			}
			rd=request.getRequestDispatcher("del_com.jsp");
			rd.forward(request, response);	
		}
 	   


	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
	}

}
