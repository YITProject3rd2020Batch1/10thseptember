package crime.controller;
import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import crime.dao.*;
import crime.model.*;



@WebServlet("/View")
public class View extends HttpServlet {
	private static final long serialVersionUID = 1L;

    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		RequestDispatcher rd;
		
		String oper="";String com_id="";
		if(request.getParameter("oper")!=null )
		{
			oper=request.getParameter("oper");
			com_id=(String)request.getParameter("com_id");
			if(oper=="modify")
			{
				rd=request.getRequestDispatcher("modify");		    
		 	    rd.forward(request, response);
			}
			else if(oper=="delete")
			{
				rd=request.getRequestDispatcher("delete");		    
		 	    rd.forward(request, response);
			}
		}
		
		
		ArrayList<String> alltype;
		alltype= ViewDAO.getAllType();
		
		request.setAttribute("alltype", alltype);
		String val="";
		
		ArrayList<Complaintmodel> allComplaint;
		
		if(request.getParameter("catg")!=null)
		{   
			val=request.getParameter("category");
			allComplaint= ViewDAO.getComplaintByType(val);
			request.setAttribute("allComplaint", allComplaint);			
		}	
			
		rd=request.getRequestDispatcher("view.jsp");		    
 	    rd.forward(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
